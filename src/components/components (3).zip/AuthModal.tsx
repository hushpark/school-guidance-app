import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import type { TeacherRole, SchoolBranding } from '../types';

export interface TeacherAccount {
  id: string;
  name: string;
  password?: string;
  role: TeacherRole;
  gradeClass?: string;
}

export interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  teachers: TeacherAccount[];
  onLoginSuccess: (user: TeacherAccount) => void;
  schoolBranding?: SchoolBranding;
}

const LOCAL_STORAGE_KEY = 'SCHOOL_GUIDANCE_TEACHERS_DATA_V1';

const DEFAULT_TEACHERS: TeacherAccount[] = [
  { id: 'admin', name: '관리자 교사', password: 'admin', role: 'admin', gradeClass: '비담임' },
  { id: 'manager', name: '인성부장 교사', password: 'manager', role: 'manager', gradeClass: '비담임' },
  { id: 'teacher1', name: '김철수 선생님', password: '1234', role: 'teacher', gradeClass: '1학년 1반' },
  { id: 'teacher2', name: '이영희 선생님', password: '1234', role: 'teacher', gradeClass: '1학년 2반' },
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  teachers,
  onLoginSuccess,
  schoolBranding,
}) => {
  const [teacherId, setTeacherId] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!teacherId.trim() || !password.trim()) {
      setErrorMessage('아이디와 비밀번호를 모두 입력해 주세요.');
      return;
    }

    setIsLoading(true);

    let activeTeachers: TeacherAccount[] = teachers;

    // 1️⃣ Supabase DB에서 실시간 교사 계정 목록 불러오기
    try {
      const { data, error } = await supabase.from('teachers').select('*');
      if (!error && data && data.length > 0) {
        activeTeachers = data.map((t: any) => ({
          id: t.id,
          name: t.name,
          password: t.password || '1234',
          role: t.role || 'teacher',
          gradeClass: t.grade_class || '비담임',
        }));
      } else {
        // DB 백업용: 로컬 스토리지 확인
        const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) activeTeachers = parsed;
        }
      }
    } catch (err) {
      console.error('교사 데이터 로드 실패:', err);
      activeTeachers = DEFAULT_TEACHERS;
    }

    // 2️⃣ 입력된 교사 ID 매칭 (대소문자 무시)
    const foundTeacher = activeTeachers.find(
      (t) => t.id.toLowerCase() === teacherId.trim().toLowerCase()
    );

    if (!foundTeacher) {
      setErrorMessage('존재하지 않는 교사 ID입니다.');
      setIsLoading(false);
      return;
    }

    // 3️⃣ 비밀번호 검증
    const validPassword = foundTeacher.password || '1234';
    if (password.trim() !== validPassword) {
      setErrorMessage('비밀번호가 올바르지 않습니다.');
      setIsLoading(false);
      return;
    }

    // 4️⃣ 로그인 성공
    onLoginSuccess(foundTeacher);
    setTeacherId('');
    setPassword('');
    setIsLoading(false);
  };

  const isTransparent = !schoolBranding?.logoBgColor || schoolBranding.logoBgColor === 'transparent';

  return (
    <div className="fixed inset-0 bg-slate-950 z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-2xl max-w-sm w-full space-y-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* 🏫 [상단 영역] 학교 브랜딩 로고 및 동적 학교명 연동 */}
        <div className="text-center space-y-2 pt-1 flex flex-col items-center">
          <div
            className={`w-14 h-14 flex items-center justify-center text-3xl transition-all ${
              isTransparent
                ? 'bg-transparent border-none shadow-none p-0'
                : 'rounded-2xl border border-slate-200/60 shadow-sm p-1'
            }`}
            style={{
              backgroundColor: isTransparent ? 'transparent' : schoolBranding?.logoBgColor,
            }}
          >
            {schoolBranding?.logoType === 'emoji' ? (
              <span>{schoolBranding?.logoValue || '🛡️'}</span>
            ) : schoolBranding?.logoValue ? (
              <img
                src={schoolBranding.logoValue}
                alt="학교 로고"
                className="w-full h-full object-contain rounded-xl"
              />
            ) : (
              <span>🛡️</span>
            )}
          </div>

          <div>
            {/* 🎯 [실시간 반영] 설정된 학교명이 로그인 창 제목으로 즉각 연동됩니다 */}
            <h2 className="text-xl font-black text-slate-800">
              {schoolBranding?.schoolName ? `${schoolBranding.schoolName} 생활지도 시스템` : '학생 생활 지도 시스템'}
            </h2>
            <p className="text-xs text-slate-400 font-medium mt-1">등록된 계정으로 로그인해 주세요.</p>
          </div>
        </div>

        {/* 🔑 로그인 폼 */}
        <form onSubmit={handleLogin} className="space-y-4">
          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-600 text-xs font-bold px-3 py-2.5 rounded-xl text-center">
              ⚠️ {errorMessage}
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block pl-1">교사 ID</label>
            <input
              type="text"
              placeholder="교사 ID 입력"
              value={teacherId}
              disabled={isLoading}
              onChange={(e) => setTeacherId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white disabled:bg-slate-100"
              autoFocus
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block pl-1">비밀번호</label>
            <input
              type="password"
              placeholder="비밀번호 입력"
              value={password}
              disabled={isLoading}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white disabled:bg-slate-100"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className={`w-full font-bold py-3.5 rounded-xl text-xs transition-all shadow-md mt-1 flex items-center justify-center gap-2 ${
              isLoading
                ? 'bg-slate-700 text-slate-300 cursor-wait'
                : 'bg-slate-900 hover:bg-slate-800 text-white cursor-pointer active:scale-98'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>로그인 처리 중...</span>
              </>
            ) : (
              <span>🔓 로그인</span>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};

export default AuthModal;