import React, { useState, useEffect } from 'react';

export interface TeacherAccount {
  id: string;
  name: string;
  password?: string;
  role: 'admin' | 'manager' | 'teacher';
  gradeClass?: string;
}

const LOCAL_STORAGE_KEY = 'SCHOOL_GUIDANCE_TEACHERS_DATA_V1';

// 💡 기본 초기 교사 계정 데이터
const DEFAULT_TEACHERS: TeacherAccount[] = [
  { id: 'admin', name: '관리자 교사', password: 'admin', role: 'admin', gradeClass: '비담임' },
  { id: 'manager', name: '인성부장 교사', password: 'manager', role: 'manager', gradeClass: '비담임' },
  { id: 'teacher1', name: '김철수 선생님', password: '1234', role: 'teacher', gradeClass: '1학년 1반' },
  { id: 'teacher2', name: '이영희 선생님', password: '1234', role: 'teacher', gradeClass: '1학년 2반' },
];

export const TeacherManageTab: React.FC = () => {
  const [subMode, setSubMode] = useState<'single' | 'batch'>('single');

  const [newId, setNewId] = useState('');
  const [newName, setNewName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'manager' | 'teacher'>('teacher');
  const [newGradeClass, setNewGradeClass] = useState('');

  const [batchText, setBatchText] = useState('');

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editRole, setEditRole] = useState<'admin' | 'manager' | 'teacher'>('teacher');
  const [editGradeClass, setEditGradeClass] = useState('');

  // 1️⃣ 실행 컴퓨터의 localStorage에서 교사 명단 불러오기 (초기 1회)
  const [teachers, setTeachers] = useState<TeacherAccount[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('로컬 저장소 교사 계정 불러오기 실패:', e);
    }
    return DEFAULT_TEACHERS;
  });

  // 2️⃣ teachers 상태가 변경될 때마다 실행 컴퓨터(localStorage)에 자동 저장
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(teachers));
    } catch (e) {
      console.error('로컬 저장소 교사 계정 저장 실패:', e);
    }
  }, [teachers]);

  const [searchQuery, setSearchQuery] = useState('');

  // 📥 1. 교사 일괄 등록 양식 받기
  const handleDownloadTeacherTemplate = () => {
    const csvContent = "\uFEFF교사ID,성명,비밀번호,담당학급\nteacher01,홍길동,1234,1학년 1반\nteacher02,김철수,1234,2학년 3반\nteacher03,이영희,1234,비담임";

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', '교사계정_일괄업로드_양식.csv');
    document.body.appendChild(link);
    link.click();

    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // 📊 2. 등록된 전체 교사 계정 엑셀 다운로드
  const handleDownloadAllTeachers = () => {
    if (teachers.length === 0) {
      alert('다운로드할 교사 계정이 없습니다.');
      return;
    }

    let csvContent = "\uFEFF교사ID,성명,비밀번호,권한,담당학급\n";

    teachers.forEach((t) => {
      const roleKor = t.role === 'admin' ? '관리자' : t.role === 'manager' ? '인성부장' : '일반교사';
      csvContent += `${t.id},${t.name},${t.password || '1234'},${roleKor},${t.gradeClass || '비담임'}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `전체_교사계정_명단_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();

    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDoubleClick = (t: TeacherAccount) => {
    setEditingId(t.id);
    setEditName(t.name);
    setEditPassword(t.password || '1234');
    setEditRole(t.role);
    setEditGradeClass(t.gradeClass || '비담임');
  };

  const handleSaveEdit = (id: string) => {
    setTeachers((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              name: editName.trim() || t.name,
              password: editPassword.trim() || t.password || '1234',
              role: editRole,
              gradeClass: editGradeClass.trim() || '비담임',
            }
          : t
      )
    );
    setEditingId(null);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  const handleAddSingleTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newId.trim() || !newName.trim()) {
      alert('교사 접속 ID와 성명을 입력해 주세요.');
      return;
    }

    if (teachers.some((t) => t.id === newId.trim())) {
      alert('이미 존재하는 접속 ID입니다.');
      return;
    }

    const newAccount: TeacherAccount = {
      id: newId.trim(),
      name: newName.trim(),
      password: newPassword.trim() || '1234',
      role: newRole,
      gradeClass: newGradeClass.trim() || '비담임',
    };

    setTeachers((prev) => [...prev, newAccount]);
    setNewId('');
    setNewName('');
    setNewPassword('');
    setNewGradeClass('');
    alert(`🎉 ${newName} 선생님의 계정(${newId})이 생성 및 저장되었습니다!`);
  };

  // 📥 교사 엑셀 붙여넣기 일괄 적용
  const handleApplyBatchTeachers = () => {
    if (!batchText.trim()) {
      alert('엑셀 계정 명단을 붙여넣어 주세요.');
      return;
    }

    const lines = batchText
      .split(/\r\n|\n|\r/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    let addedCount = 0;
    let skippedCount = 0;
    const updated = [...teachers];

    lines.forEach((line) => {
      const parts = line.split(/[\t,]+/).map((p) => p.trim()).filter((p) => p.length > 0);
      
      if (parts.length >= 2) {
        const id = parts[0];
        const name = parts[1];
        const thirdVal = parts[2] || '1234';
        const fourthVal = parts[3] || '비담임';

        const password = thirdVal.includes('반') || thirdVal.includes('학년') || thirdVal === '비담임' ? '1234' : thirdVal;
        const gradeClass = thirdVal.includes('반') || thirdVal.includes('학년') || thirdVal === '비담임' ? thirdVal : fourthVal;

        if (!updated.some((t) => t.id === id)) {
          updated.push({
            id,
            name,
            password,
            role: 'teacher',
            gradeClass,
          });
          addedCount++;
        } else {
          skippedCount++;
        }
      }
    });

    setTeachers(updated);
    setBatchText('');
    alert(`🎉 총 ${addedCount}명의 교사 계정이 일괄 생성 및 저장되었습니다!${skippedCount > 0 ? ` (중복 ID ${skippedCount}건 제외됨)` : ''}`);
  };

  const handleDeleteTeacher = (id: string, name: string) => {
    if (confirm(`${name} 선생님의 계정(${id})을 삭제하시겠습니까?`)) {
      setTeachers((prev) => prev.filter((t) => t.id !== id));
    }
  };

  const handleResetPassword = (id: string, name: string) => {
    setTeachers((prev) =>
      prev.map((t) => (t.id === id ? { ...t, password: '1234' } : t))
    );
    alert(`🔑 ${name} 선생님(${id})의 비밀번호가 [1234]로 초기화되었습니다.`);
  };

  const filteredTeachers = teachers.filter(
    (t) => t.name.includes(searchQuery) || t.id.includes(searchQuery) || (t.gradeClass && t.gradeClass.includes(searchQuery))
  );

  return (
    <div className="max-w-7xl mx-auto pb-10">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-stretch lg:h-[690px]">
        
        {/* 👈 [좌측 1열] 교사 계정 발급 폼 */}
        <div className="bg-white border border-slate-200 rounded-3xl p-4 md:p-6 shadow-sm flex flex-col justify-between min-h-[500px] lg:h-[690px]">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3 shrink-0">
            <div className="w-full sm:w-auto">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-800 flex items-center gap-1.5 whitespace-nowrap">
                <span>👑</span> 교사 계정 생성 및 발급
              </h2>
              <div className="flex items-center gap-2 mt-0.5">
                <button
                  onClick={handleDownloadTeacherTemplate}
                  className="text-[10px] font-bold text-blue-600 hover:underline cursor-pointer"
                >
                  📥 양식 받기
                </button>
                <span className="text-slate-300 text-[10px]">|</span>
                <button
                  onClick={handleDownloadAllTeachers}
                  className="text-[10px] font-bold text-emerald-700 hover:underline cursor-pointer"
                >
                  📊 전체 교사 명단 받기
                </button>
              </div>
            </div>

            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl shrink-0 w-full sm:w-auto justify-center">
              <button
                type="button"
                onClick={() => setSubMode('single')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                  subMode === 'single' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                ➕ 개별 발급
              </button>
              <button
                type="button"
                onClick={() => setSubMode('batch')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                  subMode === 'batch' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                📑 일괄 업로드
              </button>
            </div>
          </div>

          {subMode === 'single' ? (
            <form onSubmit={handleAddSingleTeacher} className="flex-1 flex flex-col justify-between py-2 space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">교사 접속 ID</label>
                  <input
                    type="text"
                    placeholder="예: teacher01"
                    value={newId}
                    onChange={(e) => setNewId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">교사 성명</label>
                  <input
                    type="text"
                    placeholder="예: 홍길동"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">초기 비밀번호</label>
                  <input
                    type="password"
                    placeholder="미입력 시 1234"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">담당 학년/반 (담임)</label>
                  <input
                    type="text"
                    placeholder="예: 1학년 1반"
                    value={newGradeClass}
                    onChange={(e) => setNewGradeClass(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 whitespace-nowrap">부여 권한</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none"
                >
                  <option value="teacher">일반교사 (조회 및 검색 전용)</option>
                  <option value="manager">인성인권부 (생활지도 입력 가능)</option>
                  <option value="admin">관리자 (전체 권한)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-2xl text-xs transition-all shadow-md shrink-0 mt-2 cursor-pointer"
              >
                🚀 신규 교사 계정 발급하기
              </button>
            </form>
          ) : (
            <div className="flex-1 flex flex-col justify-between py-2 space-y-3">
              <div className="space-y-2 flex-1 flex flex-col">
                <p className="text-xs text-slate-400">
                  엑셀에서 <b>[교사ID] [성명] [비밀번호] [담당 학년/반]</b> 열을 붙여넣으세요.
                </p>
                <textarea
                  placeholder={`[엑셀 붙여넣기 예시]\nteacher01   홍길동   pass1234   1학년 1반\nteacher02   김철수   1234       2학년 3반\nteacher03   이영희   1234       비담임`}
                  value={batchText}
                  onChange={(e) => setBatchText(e.target.value)}
                  className="w-full flex-1 min-h-[160px] bg-slate-50 border border-slate-200 rounded-2xl p-3.5 text-xs font-mono focus:outline-none focus:border-blue-500 resize-none leading-relaxed"
                />
              </div>

              <button
                onClick={handleApplyBatchTeachers}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-2xl text-xs transition-all shadow-md shrink-0 cursor-pointer"
              >
                📥 교사 계정 일괄 등록하기
              </button>
            </div>
          )}

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-[11px] text-slate-500 space-y-0.5 shrink-0 mt-2">
            <span className="font-bold text-slate-700 block">💡 비밀번호 및 계정 관리 안내</span>
            <p>• 계정 데이터는 현재 사용 중인 <b>PC 로컬 저장소에 안전하게 보존</b>됩니다.</p>
            <p>• 미입력 시 초기 비밀번호는 기본 <b>1234</b>로 등록됩니다.</p>
            <p>• 목록을 <b>더블클릭</b>하면 정보 수정 모드로 전환됩니다.</p>
          </div>
        </div>

        {/* 👉 [우측 2열] 교사 계정 명단 */}
        <div className="bg-white border border-slate-200 rounded-3xl p-4 md:p-6 shadow-sm flex flex-col justify-between min-h-[400px] lg:h-[690px]">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-3 shrink-0">
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-800 flex items-center gap-1.5 whitespace-nowrap">
                <span>📑</span> 교사 계정 명단
              </h2>
              <p className="text-xs text-slate-400 mt-0.5 whitespace-nowrap">
                등록된 교사: 총 <b>{teachers.length}명</b> (수정 시 <b>더블클릭</b>)
              </p>
            </div>
            <input
              type="text"
              placeholder="아이디, 이름, 학급 검색"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-100 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold w-full sm:w-44 focus:outline-none focus:border-blue-500 shadow-sm"
            />
          </div>

          <div className="flex-1 overflow-x-auto border border-slate-200 rounded-2xl bg-slate-50 mt-3 min-h-[300px]">
            <div className="min-w-[480px]">
              {filteredTeachers.length === 0 ? (
                <div className="text-center text-slate-400 py-20 text-xs">
                  검색된 교사 계정이 없습니다.
                </div>
              ) : (
                <div className="divide-y divide-slate-200/80">
                  <div className="bg-slate-100 px-3 py-2 text-xs font-bold text-slate-600 flex justify-between sticky top-0 shadow-sm">
                    <span className="w-1/4">교사 성명</span>
                    <span className="w-1/4">교사 ID / 권한</span>
                    <span className="w-1/4 text-center">담당 학급 (담임)</span>
                    <span className="w-1/4 text-right">계정 관리</span>
                  </div>

                  {filteredTeachers.map((t) => {
                    const isEditing = editingId === t.id;

                    return (
                      <div
                        key={t.id}
                        onDoubleClick={() => handleDoubleClick(t)}
                        className={`p-3 flex items-center justify-between text-xs transition-all cursor-pointer select-none ${
                          isEditing ? 'bg-amber-50/80 border-y border-amber-300' : 'bg-white hover:bg-slate-50'
                        }`}
                      >
                        <div className="w-1/4 pr-2">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="w-full bg-white border border-amber-400 rounded-lg px-2 py-1 font-bold text-xs focus:outline-none"
                              autoFocus
                            />
                          ) : (
                            <span className="font-bold text-slate-900 whitespace-nowrap">{t.name}</span>
                          )}
                        </div>

                        <div className="w-1/4 font-mono pr-2">
                          <span className="font-bold text-slate-700 block whitespace-nowrap">{t.id}</span>
                          {isEditing ? (
                            <div className="space-y-1 mt-1">
                              <input
                                type="text"
                                placeholder="비밀번호"
                                value={editPassword}
                                onChange={(e) => setEditPassword(e.target.value)}
                                className="w-full bg-white border border-amber-400 rounded px-1.5 py-0.5 text-[10px] font-bold"
                              />
                              <select
                                value={editRole}
                                onChange={(e) => setEditRole(e.target.value as any)}
                                className="w-full text-[10px] bg-white border border-amber-400 rounded px-1 py-0.5"
                              >
                                <option value="teacher">일반교사</option>
                                <option value="manager">인성인권부</option>
                                <option value="admin">관리자</option>
                              </select>
                            </div>
                          ) : (
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded inline-block mt-0.5 whitespace-nowrap ${
                                t.role === 'admin'
                                  ? 'bg-purple-100 text-purple-700'
                                  : t.role === 'manager'
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {t.role === 'admin' ? '관리자' : t.role === 'manager' ? '인성인권부' : '일반교사'}
                            </span>
                          )}
                        </div>

                        <div className="w-1/4 text-center px-2">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editGradeClass}
                              onChange={(e) => setEditGradeClass(e.target.value)}
                              className="w-full bg-white border border-amber-400 rounded-lg px-2 py-1 font-bold text-xs text-center focus:outline-none"
                            />
                          ) : (
                            <span
                              className={`font-bold px-2 py-0.5 rounded-lg text-xs whitespace-nowrap ${
                                t.gradeClass && t.gradeClass !== '비담임'
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                  : 'text-slate-400'
                              }`}
                            >
                              {t.gradeClass || '비담임'}
                            </span>
                          )}
                        </div>

                        <div className="w-1/4 flex gap-1 justify-end shrink-0">
                          {isEditing ? (
                            <>
                              <button
                                onClick={() => handleSaveEdit(t.id)}
                                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-2 py-1 rounded-lg text-xs whitespace-nowrap"
                              >
                                저장
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold px-2 py-1 rounded-lg text-xs whitespace-nowrap"
                              >
                                취소
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleResetPassword(t.id, t.name);
                                }}
                                className="bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2 py-1 rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap"
                                title="비밀번호 초기화(1234)"
                              >
                                🔑 초기화
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteTeacher(t.id, t.name);
                                }}
                                className="bg-slate-100 hover:bg-rose-600 hover:text-white text-slate-500 px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                                title="계정 삭제"
                              >
                                🗑️ 삭제
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default TeacherManageTab;