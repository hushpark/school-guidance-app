import React, { useState, useEffect } from 'react';
import type { Student, ClassCounts, TeacherRole } from '../types';
import { saveStoredStudents } from '../utils/studentStorage';

interface ClassGridTabProps {
  role: TeacherRole;
  students: Student[];
  classCounts: ClassCounts;
  studentPenaltyCounts: Record<string, { count: number; first7thDate?: string }>;
  penalties?: any[];
  warningThreshold?: number;
  focusThreshold?: number;
  onStudentsUpdated: (newStudents: Student[]) => void;
  // 🗑️ 단속 삭제 처리용 콜백 함수
  onDeletePenalty?: (penaltyId: string) => void;
}

interface GuidanceRecord {
  completed: boolean;
  date?: string;
  memo?: string;
}

const GUIDANCE_RECORDS_KEY = 'SCHOOL_GUIDANCE_COMPLETED_RECORDS';

export const ClassGridTab: React.FC<ClassGridTabProps> = ({
  role,
  students,
  classCounts,
  studentPenaltyCounts,
  penalties = [],
  warningThreshold = 4,
  focusThreshold = 7,
  onStudentsUpdated,
  onDeletePenalty,
}) => {
  const [selectedGrade, setSelectedGrade] = useState<number>(1);
  
  // 🎯 서브 탭 상태 ('grid': 반별 누적 / 'date': 일자별 단속 / 'list': 기준별 누적)
  const [subTab, setSubTab] = useState<'grid' | 'date' | 'list'>('grid');
  
  // 📅 일자별 단속 조회 전용 날짜 상태 (기본값: 오늘 YYYY-MM-DD)
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().slice(0, 10)
  );

  const [guidanceRecords, setGuidanceRecords] = useState<Record<string, GuidanceRecord>>({});
  const [memoModalStudent, setMemoModalStudent] = useState<{ id: string; name: string } | null>(null);
  const [memoInput, setMemoInput] = useState('');

  const currentGradeClassCount = classCounts[selectedGrade] || 10;
  const isAdmin = role === 'admin';
  const isPrivileged = role === 'admin' || role === 'manager';

  const todayStr = new Date().toLocaleDateString('sv-SE');

  useEffect(() => {
    const saved = localStorage.getItem(GUIDANCE_RECORDS_KEY);
    if (saved) {
      try {
        setGuidanceRecords(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load guidance records', e);
      }
    }
  }, []);

  const saveRecords = (newRecords: Record<string, GuidanceRecord>) => {
    setGuidanceRecords(newRecords);
    localStorage.setItem(GUIDANCE_RECORDS_KEY, JSON.stringify(newRecords));
  };

  const handleToggleGuidance = (studentId: string) => {
    const current = guidanceRecords[studentId];
    const isCompleted = current?.completed;

    const newRecords = {
      ...guidanceRecords,
      [studentId]: {
        completed: !isCompleted,
        date: !isCompleted ? new Date().toLocaleDateString('ko-KR') : undefined,
        memo: !isCompleted ? current?.memo || '' : undefined,
      },
    };
    saveRecords(newRecords);
  };

  const handleSaveMemo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memoModalStudent) return;

    const studentId = memoModalStudent.id;
    const current = guidanceRecords[studentId];

    const newRecords = {
      ...guidanceRecords,
      [studentId]: {
        completed: true,
        date: current?.date || new Date().toLocaleDateString('ko-KR'),
        memo: memoInput.trim(),
      },
    };

    saveRecords(newRecords);
    setMemoModalStudent(null);
    setMemoInput('');
  };

  // 날짜 유틸리티
  const getTodayDate = () => new Date().toISOString().slice(0, 10);
  const getYesterdayDate = () => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
  };

  // 🗑️ 일자별 단속 내역 즉시 삭제 처리
  const handleDeletePenaltyItem = (penaltyId: string, studentName: string) => {
    if (confirm(`🚨 [${studentName}] 학생의 ${selectedDate} 단속 기록을 삭제하시겠습니까?`)) {
      if (onDeletePenalty) {
        onDeletePenalty(penaltyId);
      } else {
        alert('삭제 콜백 함수가 연동되지 않았습니다. App.tsx 내 onDeletePenalty를 확인해주세요.');
      }
    }
  };

  // 📅 특정 날짜에 실제로 단속된 기록만 필터링
  const datePenalties = penalties.filter((p) => {
    if (!p.created_at) return false;
    const penaltyDate = new Date(p.created_at).toISOString().slice(0, 10);
    return penaltyDate === selectedDate;
  });

  // 해당 날짜 단속 학생 상세 목록 매칭
  const datePenaltyStudents = datePenalties.map((p) => {
    const student = students.find((s) => s.id === p.student_id);
    return {
      penaltyId: p.id,
      time: new Date(p.created_at).toLocaleTimeString('ko-KR', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      studentId: p.student_id,
      name: student ? student.name : '(등록 학생 없음)',
      grade: student ? student.grade : Math.floor(Number(p.student_id) / 10000),
      classNum: student ? student.classNum : Math.floor((Number(p.student_id) % 10000) / 100),
      number: student ? student.number : Number(p.student_id) % 100,
      totalCount: studentPenaltyCounts[p.student_id]?.count || 1,
    };
  });

  // 📅 일자별 단속 명단 엑셀 다운로드
  const handleDownloadDatePenalties = () => {
    if (datePenaltyStudents.length === 0) {
      alert('다운로드할 단속 명단이 없습니다.');
      return;
    }

    let csvContent = `\uFEFF단속일자,단속시간,학년,반,번호,성명,현재누적단속횟수\n`;
    datePenaltyStudents.forEach((s) => {
      csvContent += `${selectedDate},${s.time},${s.grade},${s.classNum},${s.number},${s.name},${s.totalCount}회\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `단속학생명단_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const todayPenalizedStudentIds = new Set(
    penalties
      .filter((p) => p.created_at && new Date(p.created_at).toLocaleDateString('sv-SE') === todayStr)
      .map((p) => p.student_id)
  );

  const warningList = students
    .map((s) => ({
      student: s,
      count: studentPenaltyCounts[s.id]?.count || 0,
    }))
    .filter((item) => item.count >= warningThreshold && item.count < focusThreshold)
    .sort((a, b) => b.count - a.count);

  const focusList = students
    .map((s) => ({
      student: s,
      count: studentPenaltyCounts[s.id]?.count || 0,
      first7thDate: studentPenaltyCounts[s.id]?.first7thDate,
    }))
    .filter((item) => item.count >= focusThreshold)
    .sort((a, b) => b.count - a.count);

  const handleNameChange = (studentId: string, newName: string) => {
    const updated = students.map((s) => (s.id === studentId ? { ...s, name: newName } : s));
    saveStoredStudents(updated);
    onStudentsUpdated(updated);
  };

  const handlePaste = (
    e: React.ClipboardEvent<HTMLInputElement>,
    startGrade: number,
    startClassNum: number,
    startNumber: number
  ) => {
    if (!isAdmin) return;

    const pasteData = e.clipboardData.getData('text');
    const pastedLines = pasteData
      .split(/\r\n|\n|\r/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    if (pastedLines.length <= 1) return;

    e.preventDefault();

    let updatedStudents = [...students];

    pastedLines.forEach((name, index) => {
      const targetNumber = startNumber + index;
      const formattedClass = String(startClassNum).padStart(2, '0');
      const formattedNumber = String(targetNumber).padStart(2, '0');
      const targetId = `${startGrade}${formattedClass}${formattedNumber}`;

      const existingIndex = updatedStudents.findIndex((s) => s.id === targetId);

      if (existingIndex !== -1) {
        updatedStudents[existingIndex] = { ...updatedStudents[existingIndex], name };
      } else {
        updatedStudents.push({
          id: targetId,
          grade: startGrade,
          classNum: startClassNum,
          number: targetNumber,
          name,
        });
      }
    });

    saveStoredStudents(updatedStudents);
    onStudentsUpdated(updatedStudents);
  };

  return (
    <div className="space-y-2 flex flex-col relative">
      
      {/* 💬 메모 작성 Modal */}
      {memoModalStudent && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 shadow-2xl max-w-md w-full border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-sm text-slate-800 flex items-center gap-1.5">
                <span>📝</span> 집중지도 메모 ({memoModalStudent.name})
              </h3>
              <button
                onClick={() => setMemoModalStudent(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveMemo} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  지도 및 상담 내용
                </label>
                <textarea
                  value={memoInput}
                  onChange={(e) => setMemoInput(e.target.value)}
                  placeholder="예: 학부모 상담 진행, 교내 선도 조치 완료 등"
                  className="w-full bg-slate-50 border border-slate-300 rounded-2xl p-3 text-xs font-medium text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white resize-none h-24"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setMemoModalStudent(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-600 hover:bg-slate-200 cursor-pointer"
                >
                  취소
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow-md cursor-pointer"
                >
                  지도 완료 저장
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 🔝 상단 서브 탭 & 컨트롤 바 */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-2.5 rounded-2xl border border-slate-200 shadow-sm shrink-0 gap-2">
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          
          {/* 서브 탭 스위치 3종 (모바일 '반별', '일자별', '기준별' 축소 텍스트 적용) */}
          <div className="flex gap-1 bg-slate-100/80 p-1 rounded-2xl border border-slate-200/60">
            <button
              onClick={() => setSubTab('grid')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                subTab === 'grid'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-700 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <span>📊</span>
              <span className="md:hidden">반별</span>
              <span className="hidden md:inline">반별 누적 명단</span>
            </button>

            <button
              onClick={() => setSubTab('date')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                subTab === 'date'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-700 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <span>📅</span>
              <span className="md:hidden">일자별</span>
              <span className="hidden md:inline">일자별 단속 명단</span>
            </button>

            {isPrivileged && (
              <button
                onClick={() => setSubTab('list')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  subTab === 'list'
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-white text-slate-700 hover:text-rose-600 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                <span>📋</span>
                <span className="md:hidden">기준별</span>
                <span className="hidden md:inline">기준별 누적 명단</span>
              </button>
            )}
          </div>

          {/* 학년 선택 (반별 누적 명단 탭일 때) */}
          {subTab === 'grid' && (
            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
              <label htmlFor="grade-select" className="text-xs font-bold text-slate-700 shrink-0 whitespace-nowrap">
                🏫 학년:
              </label>
              <select
                id="grade-select"
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(Number(e.target.value))}
                className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 cursor-pointer shadow-sm"
              >
                {[1, 2, 3].map((g) => (
                  <option key={g} value={g}>
                    {g}학년 ({classCounts[g] || 10}개 반)
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* 날짜 선택 및 다운로드 컨트롤 (일자별 단속 명단 탭일 때) */}
        {subTab === 'date' && (
          <div className="flex items-center gap-2 flex-wrap w-full md:w-auto justify-between md:justify-end">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSelectedDate(getTodayDate())}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedDate === getTodayDate()
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                오늘
              </button>
              <button
                onClick={() => setSelectedDate(getYesterdayDate())}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedDate === getYesterdayDate()
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                어제
              </button>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1 font-bold text-xs text-slate-800 focus:outline-none cursor-pointer"
              />
            </div>

            <button
              onClick={handleDownloadDatePenalties}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1 rounded-xl text-xs transition-all shadow-sm cursor-pointer whitespace-nowrap"
            >
              📥 명단 다운로드
            </button>
          </div>
        )}

        {/* 범례 및 안내 박스 (반별 누적 명단 탭일 때) */}
        {subTab === 'grid' && (
          <div className="text-[11px] text-slate-500 font-medium flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200 flex-wrap">
              <span className="flex items-center gap-1 font-bold text-slate-700 whitespace-nowrap">
                <span className="w-2 h-2 rounded-full bg-amber-400 inline-block"></span>
                {warningThreshold}~{focusThreshold - 1}회
              </span>
              <span className="text-slate-300">|</span>
              <span className="flex items-center gap-1 font-bold text-slate-700 whitespace-nowrap">
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
                {focusThreshold}회 이상
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-rose-600 font-black whitespace-nowrap">▲ 오늘지도</span>
            </div>
          </div>
        )}
      </div>

      {/* ───────────────────────────────────────────────────────────── */}

      {/* 1️⃣ 반별 누적 현황판 (기존 그리드) */}
      {subTab === 'grid' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-1.5 pb-2">
          {Array.from({ length: currentGradeClassCount }, (_, i) => i + 1).map((classNum) => {
            const classStudents = students.filter(
              (s) => s.grade === selectedGrade && s.classNum === classNum
            );

            return (
              <div key={classNum} className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
                <div className="bg-slate-800 border-b border-slate-700 py-1 px-2 text-xs font-bold text-white relative flex items-center justify-center shrink-0">
                  <span className="text-center">{classNum}반</span>
                  <span className="absolute right-1.5 text-[9px] font-normal text-slate-400 font-mono">
                    {classStudents.length}명
                  </span>
                </div>

                <div className="divide-y divide-slate-100 overflow-y-auto max-h-[695px]">
                  {classStudents.length === 0 ? (
                    <div className="text-center text-slate-400 py-6 text-[10px]">명단 없음</div>
                  ) : (
                    classStudents.map((st) => {
                      const count = studentPenaltyCounts[st.id]?.count || 0;
                      const isToday = todayPenalizedStudentIds.has(st.id);
                      const isMissingNum = st.name.includes('결번') || st.name.includes('궐번');
                      const isWarning = count >= warningThreshold && count < focusThreshold;
                      const isFocus = count >= focusThreshold;

                      let nameBgColor = '';
                      if (isFocus) nameBgColor = 'bg-rose-100 border-rose-200 text-rose-950 font-bold';
                      else if (isWarning) nameBgColor = 'bg-amber-100 border-amber-200 text-amber-950 font-bold';

                      return (
                        <div
                          key={st.id}
                          className={`px-1 py-[1px] h-[22.9px] flex items-center justify-between transition-colors ${
                            isMissingNum ? 'bg-rose-50/70' : 'hover:bg-slate-50'
                          }`}
                        >
                          <span className={`font-mono text-[11px] font-normal whitespace-nowrap mr-0.5 min-w-[14px] text-right ${
                            isMissingNum ? 'text-rose-400' : 'text-slate-400'
                          }`}>
                            {st.number}
                          </span>

                          {isAdmin ? (
                            <input
                              type="text"
                              value={st.name}
                              onChange={(e) => handleNameChange(st.id, e.target.value)}
                              onPaste={(e) => handlePaste(e, st.grade, st.classNum, st.number)}
                              className={`w-full mx-0.5 px-0.5 py-0 text-[12px] font-medium rounded focus:outline-none focus:bg-emerald-50 focus:border-emerald-400 border border-transparent hover:border-slate-300 ${nameBgColor} ${
                                isMissingNum ? 'text-rose-600 font-bold' : 'text-slate-800'
                              }`}
                            />
                          ) : (
                            <span className={`font-medium text-[12px] truncate flex-1 text-left px-0.5 py-0 rounded ${nameBgColor} ${
                              isMissingNum ? 'text-rose-600' : 'text-slate-800'
                            }`}>
                              {st.name}
                            </span>
                          )}

                          <span
                            className={`font-mono font-bold px-0.5 py-0 rounded text-[10px] min-w-[16px] text-center shrink-0 flex items-center justify-center gap-0.5 ${
                              isMissingNum ? 'bg-rose-100/50 text-rose-300 border border-rose-200/50' :
                              isFocus ? 'bg-rose-600 text-white' :
                              isWarning ? 'bg-amber-500 text-white' :
                              count >= 1 ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'text-slate-300 font-normal'
                            }`}
                          >
                            {isMissingNum ? '-' : count > 0 ? `${count}` : '-'}
                            
                            {isToday && !isMissingNum && (
                              <span className={`font-black animate-bounce inline-block ${isFocus ? 'text-white' : 'text-rose-600'}`}>
                                ▲
                              </span>
                            )}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 2️⃣ 📅 일자별 단속 명단 (개별 삭제 연동 기능 추가 ⭐) */}
      {subTab === 'date' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-4 min-h-[400px]">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-extrabold text-slate-800 flex items-center gap-2">
                <span>📅</span> 
                <span>{selectedDate} 단속 학생 명단</span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-full font-mono">
                  총 {datePenaltyStudents.length}명
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                선택하신 날짜에 실제로 지도 등록된 학생 목록입니다. 잘못 등록된 경우 우측 🗑️ 아이콘으로 삭제할 수 있습니다.
              </p>
            </div>
          </div>

          {datePenaltyStudents.length === 0 ? (
            <div className="text-center text-slate-400 py-32 text-xs">
              선택하신 날짜({selectedDate})에는 단속된 학생이 없습니다. 🎉 (0명)
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {datePenaltyStudents.map((item, idx) => (
                <div
                  key={item.penaltyId || idx}
                  className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 flex justify-between items-center hover:bg-slate-100/80 transition-all shadow-sm"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                        {item.time}
                      </span>
                      <span className="font-bold text-xs text-slate-700">
                        {item.grade}학년 {item.classNum}반 {item.number}번
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pt-0.5">
                      <span className="font-extrabold text-sm text-slate-900">
                        {item.name}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 bg-slate-200 px-1.5 py-0.5 rounded-md font-mono">
                        현재 누적 {item.totalCount}회
                      </span>
                    </div>
                  </div>

                  {/* 🗑️ 단속 기록 삭제 버튼 */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDeletePenaltyItem(item.penaltyId, item.name)}
                      className="p-1.5 rounded-xl bg-white border border-slate-200 hover:bg-rose-50 hover:border-rose-200 text-slate-400 hover:text-rose-600 transition-all cursor-pointer shadow-sm"
                      title="이 단속 기록 삭제"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 3️⃣ 기준별 지도 명단 표 */}
      {subTab === 'list' && isPrivileged && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          
          {/* 🟡 4회 이상 명단 */}
          <div className="bg-white border border-amber-200 rounded-2xl p-3 md:p-4 shadow-sm space-y-3 h-fit">
            <div className="bg-amber-100 border border-amber-300 p-2 rounded-xl text-center">
              <h3 className="font-black text-amber-900 text-xs">
                🟡 {warningThreshold}회 이상 명단 ({warningList.length}명)
              </h3>
            </div>

            <div className="overflow-x-auto border border-amber-200 rounded-xl">
              <table className="w-full text-xs text-center border-collapse min-w-[240px]">
                <thead>
                  <tr className="bg-amber-50 text-amber-900 font-bold border-b border-amber-200">
                    <th className="py-2 px-2">학번</th>
                    <th className="py-2 px-2">이름</th>
                    <th className="py-2 px-2">횟수</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-amber-100 font-medium text-slate-800">
                  {warningList.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="py-6 text-slate-400">대상 학생이 없습니다.</td>
                    </tr>
                  ) : (
                    warningList.map(({ student, count }) => (
                      <tr key={student.id} className="hover:bg-amber-50/50 transition-all">
                        <td className="py-2 px-2 font-mono text-slate-400">{student.id}</td>
                        <td className="py-2 px-2 font-bold">{student.name}</td>
                        <td className="py-2 px-2">
                          <span className="bg-amber-500 text-white font-bold px-2 py-0.5 rounded-full text-[10px]">
                            {count}회
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* 🔴 7회 이상 집중지도 명단 */}
          <div className="bg-white border border-rose-200 rounded-2xl p-3 md:p-4 shadow-sm space-y-3 h-fit">
            <div className="bg-rose-600 p-2 rounded-xl text-center text-white flex justify-between items-center px-3">
              <h3 className="font-black text-xs">
                🔴 {focusThreshold}회 이상 집중지도 명단 ({focusList.length}명)
              </h3>
              <span className="text-[10px] opacity-80 font-normal hidden sm:inline-block">
                💡 클릭: 완료 토글 / ✏️: 메모
              </span>
            </div>

            <div className="overflow-x-auto border border-rose-200 rounded-xl">
              <table className="w-full text-xs text-center border-collapse min-w-[320px]">
                <thead>
                  <tr className="bg-rose-50 text-rose-900 font-bold border-b border-rose-200">
                    <th className="py-2 px-1.5">학번</th>
                    <th className="py-2 px-1.5">이름</th>
                    <th className="py-2 px-1.5">횟수</th>
                    <th className="py-2 px-1.5">7회 달성일</th>
                    <th className="py-2 px-1.5">지도 상태</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-rose-100 font-medium text-slate-800">
                  {focusList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-slate-400">대상 학생이 없습니다.</td>
                    </tr>
                  ) : (
                    focusList.map(({ student, count, first7thDate }) => {
                      const record = guidanceRecords[student.id];
                      const isCompleted = record?.completed;

                      return (
                        <tr key={student.id} className="hover:bg-rose-50/50 transition-all">
                          <td className="py-2 px-1.5 font-mono text-slate-400 text-[11px]">{student.id}</td>
                          <td className="py-2 px-1.5 font-bold text-rose-900">{student.name}</td>
                          <td className="py-2 px-1.5">
                            <span className="bg-rose-600 text-white font-bold px-1.5 py-0.5 rounded-full text-[10px]">
                              {count}회
                            </span>
                          </td>
                          <td className="py-2 px-1.5 font-mono text-slate-500 text-[10px]">
                            {first7thDate || '최근'}
                          </td>
                          <td className="py-2 px-1.5">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                onClick={() => handleToggleGuidance(student.id)}
                                title={record?.memo ? `메모: ${record.memo}` : '클릭하여 상태 전환'}
                                className={`px-2 py-0.5 rounded-xl text-[10px] font-extrabold transition-all shadow-sm flex items-center gap-0.5 whitespace-nowrap cursor-pointer ${
                                  isCompleted
                                    ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                                    : 'bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-300'
                                }`}
                              >
                                {isCompleted ? (
                                  <>
                                    <span>✅ 완료</span>
                                    {record?.date && <span className="opacity-80 font-mono text-[8px]">({record.date})</span>}
                                  </>
                                ) : (
                                  <span>⚠️ 미지도</span>
                                )}
                              </button>

                              <button
                                onClick={() => {
                                  setMemoModalStudent({ id: student.id, name: student.name });
                                  setMemoInput(record?.memo || '');
                                }}
                                className="p-0.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                                title="상담 및 지도 메모 작성"
                              >
                                ✏️
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};

export default ClassGridTab;