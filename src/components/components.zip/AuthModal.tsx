import React, { useState } from 'react';
import type { TeacherRole, SchoolBranding } from '../types';

export interface TeacherAccount {
  id: string;
  name: string;
  password?: string;
  role: TeacherRole;
  gradeClass?: string;
}

export interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  teachers: TeacherAccount[];
  onLoginSuccess: (user: TeacherAccount) => void;
  schoolBranding?: SchoolBranding;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  teachers,
  onLoginSuccess,
  schoolBranding,
}) => {
  const [teacherId, setTeacherId] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!teacherId.trim() || !password.trim()) {
      setErrorMessage('아이디와 비밀번호를 모두 입력해 주세요.');
      return;
    }

    const foundTeacher = teachers.find(
      (t) => t.id.toLowerCase() === teacherId.trim().toLowerCase()
    );

    if (!foundTeacher) {
      setErrorMessage('존재하지 않는 교사 ID입니다.');
      return;
    }

    const validPassword = foundTeacher.password || '1234';
    if (password.trim() !== validPassword) {
      setErrorMessage('비밀번호가 올바르지 않습니다.');
      return;
    }

    // ❌ 로그인 완료 알림 팝업(alert)을 완전히 제거하여 바로 이동합니다.
    onLoginSuccess(foundTeacher);
    setTeacherId('');
    setPassword('');
  };

  const isTransparent = !schoolBranding?.logoBgColor || schoolBranding.logoBgColor === 'transparent';

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-3xl p-7 shadow-2xl max-w-sm w-full space-y-5 animate-in fade-in zoom-in-95 duration-200">
        
        {/* 🏫 [상단 영역] 학교 브랜딩 로고 */}
        <div className="text-center space-y-2 pt-1 flex flex-col items-center">
          <div
            className={`w-12 h-12 flex items-center justify-center text-3xl transition-all ${
              isTransparent
                ? 'bg-transparent border-none shadow-none p-0'
                : 'rounded-2xl border border-slate-200/60 shadow-sm p-1'
            }`}
            style={{
              backgroundColor: isTransparent ? 'transparent' : schoolBranding?.logoBgColor,
            }}
          >
            {schoolBranding?.logoType === 'emoji' ? (
              <span>{schoolBranding?.logoValue || '🛡️'}</span>
            ) : schoolBranding?.logoValue ? (
              <img
                src={schoolBranding.logoValue}
                alt="학교 로고"
                className="w-full h-full object-contain rounded-xl"
              />
            ) : (
              <span>🛡️</span>
            )}
          </div>

          <div>
            <h2 className="text-xl font-black text-slate-800">학생 생활 지도 시스템</h2>
            <p className="text-xs text-slate-400 font-medium mt-0.5">등록된 계정으로 로그인해 주세요.</p>
          </div>
        </div>

        {/* 🔑 로그인 폼 */}
        <form onSubmit={handleLogin} className="space-y-3.5">
          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-600 text-xs font-bold px-3 py-2 rounded-xl text-center">
              ⚠️ {errorMessage}
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block pl-1">교사 ID</label>
            <input
              type="text"
              placeholder="교사 ID 입력"
              value={teacherId}
              onChange={(e) => setTeacherId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
              autoFocus
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block pl-1">비밀번호</label>
            <input
              type="password"
              placeholder="비밀번호 입력"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-xs transition-all shadow-md cursor-pointer"
          >
            🔓 로그인
          </button>
        </form>

      </div>
    </div>
  );
};