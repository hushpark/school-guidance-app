import React, { useState, useRef, useEffect } from 'react';
import { supabase, clearSupabaseConfig } from '../lib/supabase';
import type { Student, ClassCounts, SchoolBranding, PhotoConfig } from '../types';
import { saveStoredStudents, resetStoredStudents } from '../utils/studentStorage';

interface SystemConfigTabProps {
  students: Student[];
  classCounts: ClassCounts;
  warningThreshold: number;
  focusThreshold: number;
  schoolBranding: SchoolBranding;
  photoConfig: PhotoConfig;
  onClassCountChange: (grade: number, count: number) => void;
  onThresholdChange: (warning: number, focus: number) => void;
  onStudentsUpdated: (newStudents: Student[]) => void;
  onResetPenalties: () => void;
  onSchoolBrandingChange: (branding: SchoolBranding) => void;
  onPhotoConfigChange: (config: PhotoConfig) => void;
  rulesPdfUrl?: string;
  onUpdateRulesPdfUrl?: (url: string) => void;
}

interface PromotionResult {
  oldId: string;
  newId: string;
  name: string;
}

const PRESET_COLORS = [
  'transparent',
  '#ffffff',
  '#d1fae5',
  '#dbeafe',
  '#fef3c7',
  '#fce7f3',
];

export const SystemConfigTab: React.FC<SystemConfigTabProps> = ({
  students,
  classCounts,
  warningThreshold,
  focusThreshold,
  schoolBranding,
  photoConfig,
  onClassCountChange,
  onThresholdChange,
  onStudentsUpdated,
  onResetPenalties,
  onSchoolBrandingChange,
  onPhotoConfigChange,
  rulesPdfUrl,
  onUpdateRulesPdfUrl,
}) => {
  const [warningInput, setWarningInput] = useState(warningThreshold);
  const [focusInput, setFocusInput] = useState(focusThreshold);

  const [schoolNameInput, setSchoolNameInput] = useState(schoolBranding.schoolName);
  const [logoTypeInput, setLogoTypeInput] = useState<'emoji' | 'image' | 'file'>(schoolBranding.logoType || 'emoji');
  const [logoValueInput, setLogoValueInput] = useState(schoolBranding.logoValue);
  const [logoBgColorInput, setLogoBgColorInput] = useState<string>(schoolBranding.logoBgColor || 'transparent');

  const [tunnelMode, setTunnelMode] = useState<'hybrid' | 'auto' | 'manual'>('hybrid');
  const colorInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if ((window as any).electron?.getTunnelStatus) {
      (window as any).electron.getTunnelStatus().then((res: any) => {
        if (res?.mode) setTunnelMode(res.mode);
      });
    }
  }, []);

  const saveConfigToSupabase = async (key: string, value: any) => {
    try {
      const stringValue = typeof value === 'object' ? JSON.stringify(value) : String(value);

      const { error } = await supabase.from('settings').upsert(
        {
          key: key,
          value: stringValue,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'key' }
      );

      if (error) {
        console.warn('settings 테이블 저장 참고:', error.message);
      }
    } catch (err) {
      console.error('DB 동기화 오류:', err);
    }
  };

  const handleTunnelModeChange = async (newMode: 'hybrid' | 'auto' | 'manual') => {
    setTunnelMode(newMode);
    if ((window as any).electron?.setTunnelMode) {
      await (window as any).electron.setTunnelMode(newMode);
      const modeNames = {
        hybrid: '하이브리드(내, 외부망)',
        auto: '자동(외부망)',
        manual: '수동(관리자)',
      };
      alert(`🎉 외부 접속 구동 방식이 [${modeNames[newMode]}] 모드로 변경되었습니다.`);
    } else {
      alert('⚠️ Electron 데스크톱 앱 환경에서만 터널 모드를 변경할 수 있습니다.');
    }
  };

  const handleGenerateInitialData = async () => {
    if (!confirm('🎁 시연 및 테스트용 초기 샘플 데이터(교사 계정 및 학생 명단)를 DB에 생성하시겠습니까?')) {
      return;
    }

    try {
      const demoTeachers = [
        { id: 'admin', name: '관리자 교사', password: 'admin', role: 'admin', grade_class: '비담임' },
        { id: 'manager', name: '인성부장 교사', password: 'manager', role: 'manager', grade_class: '비담임' },
        { id: 'teacher1', name: '김철수 선생님', password: '1234', role: 'teacher', grade_class: '1학년 1반' },
        { id: 'teacher2', name: '이영희 선생님', password: '1234', role: 'teacher', grade_class: '1학년 2반' },
      ];

      const { error: teacherError } = await supabase.from('teachers').upsert(demoTeachers);
      if (teacherError) {
        alert(`⚠️ 교사 DB 저장 실패: ${teacherError.message}`);
        return;
      }

      const resetStudents = resetStoredStudents();
      const formattedStudents = resetStudents.map((s) => ({
        ...s,
        photoUrl: `/photos/${s.id}.jpg`,
      }));

      const { error: studentError } = await supabase.from('students').upsert(
        formattedStudents.map((s) => ({
          id: s.id,
          name: s.name,
          grade: s.grade,
          class_num: s.classNum,
          number: s.number,
          photo_url: `/photos/${s.id}.jpg`,
        }))
      );

      if (studentError) {
        alert(`⚠️ 학생 DB 저장 실패: ${studentError.message}`);
        return;
      }

      saveStoredStudents(formattedStudents);
      onStudentsUpdated(formattedStudents);

      alert('🎉 시연용 교사 계정 및 학생 명단이 DB에 성공적으로 등록되었습니다!\n페이지를 새로고침합니다.');
      window.location.reload();
    } catch (e: any) {
      console.error(e);
      alert(`시연 데이터 생성 중 오류 발생: ${e?.message || e}`);
    }
  };

  const handleResetDbConfig = () => {
    if (confirm('🔑 현재 연동된 Supabase DB Key를 삭제하고 초기화하시겠습니까?\n확인을 누르면 초기 연동 설정 팝업이 다시 표시됩니다.')) {
      clearSupabaseConfig();
    }
  };

  const updateRealtimeBranding = (field: Partial<SchoolBranding>) => {
    const updated: SchoolBranding = {
      schoolName: field.schoolName !== undefined ? field.schoolName : schoolNameInput,
      logoType: field.logoType !== undefined ? field.logoType : logoTypeInput,
      logoValue: field.logoValue !== undefined ? field.logoValue : logoValueInput,
      logoBgColor: field.logoBgColor !== undefined ? field.logoBgColor : logoBgColorInput,
    };
    onSchoolBrandingChange(updated);
  };

  const openColorPicker = () => {
    const el = colorInputRef.current;
    if (el) {
      if ('showPicker' in el && typeof (el as any).showPicker === 'function') {
        try {
          (el as any).showPicker();
        } catch {
          el.click();
        }
      } else {
        el.click();
      }
    }
  };

  const [promotionText, setPromotionText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [appliedPromotionResults, setAppliedPromotionResults] = useState<PromotionResult[]>([]);

  const handlePdfFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      alert('⚠️ PDF 파일만 업로드할 수 있습니다.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert('⚠️ 파일 크기가 10MB를 초과합니다.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (onUpdateRulesPdfUrl) {
        onUpdateRulesPdfUrl(result);
        saveConfigToSupabase('rules_pdf_url', result);
        alert('🎉 학생 생활 지도 규정 PDF가 성공적으로 등록되었습니다!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDeletePdf = () => {
    if (confirm('📜 등록된 학생 생활 지도 규정 PDF를 삭제하시겠습니까?')) {
      if (onUpdateRulesPdfUrl) {
        onUpdateRulesPdfUrl('');
        saveConfigToSupabase('rules_pdf_url', '');
        alert('삭제되었습니다.');
      }
    }
  };

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('로고 이미지 용량은 2MB 이하만 등록 가능합니다.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        const val = event.target.result as string;
        setLogoValueInput(val);
        updateRealtimeBranding({ logoValue: val });
      }
    };
    reader.readAsDataURL(file);
  };

  const parsePromotionPreview = () => {
    if (!promotionText.trim()) return [];
    const lines = promotionText.split(/\r\n|\n|\r/).map((line) => line.trim()).filter((line) => line.length > 0);
    const previewList: PromotionResult[] = [];

    lines.forEach((line) => {
      const parts = line.split(/[\t\s]+/).map((p) => p.trim()).filter((p) => p.length > 0);

      if (parts.length >= 2) {
        const oldId = parts[0];
        const rawNewId = parts[parts.length - 1];

        const matchedStudent = students.find((s) => s.id === oldId);
        const name = matchedStudent ? matchedStudent.name : (parts.length >= 3 ? parts[1] : '(미등록)');

        const isGraduated = rawNewId.includes('졸업') || rawNewId === '0';
        const displayNewId = isGraduated ? '🎓 졸업' : rawNewId;

        previewList.push({ oldId, newId: displayNewId, name });
      }
    });
    return previewList;
  };

  const previewData = parsePromotionPreview();

  const handleSaveBranding = () => {
    const updated: SchoolBranding = {
      schoolName: schoolNameInput.trim() || '한국고등학교',
      logoType: logoTypeInput,
      logoValue: logoValueInput.trim() || (logoTypeInput === 'emoji' ? '⚖️' : ''),
      logoBgColor: logoBgColorInput,
    };
    onSchoolBrandingChange(updated);
    saveConfigToSupabase('school_branding', updated);
    alert('🎉 학교 브랜딩 설정이 DB에 성공적으로 저장되었습니다!');
  };

  const handleSaveThresholds = () => {
    if (warningInput >= focusInput) {
      alert('1단계(경고) 기준 횟수는 2단계(집중지도) 기준 횟수보다 작아야 합니다.');
      return;
    }
    onThresholdChange(warningInput, focusInput);
    saveConfigToSupabase('thresholds', {
      warning_threshold: warningInput,
      focus_threshold: focusInput,
    });
    alert(`지도 기준이 DB에 저장되었습니다!\n- 1단계 경고: ${warningInput}회\n- 2단계 집중지도: ${focusInput}회`);
  };

  const handleClassCountChangeAndSave = (grade: number, count: number) => {
    onClassCountChange(grade, count);
    const updatedCounts = { ...classCounts, [grade]: count };
    saveConfigToSupabase('class_counts', updatedCounts);
  };

  const handleApplyPromotion = async () => {
    if (previewData.length === 0) {
      alert('진급 매칭 명단(이전 학번과 새 학번)을 붙여넣어 주세요.');
      return;
    }

    setIsProcessing(true);
    let updatedStudents = [...students];
    const resultsLog: PromotionResult[] = [];

    previewData.forEach(({ oldId, newId }) => {
      if (newId.includes('졸업')) {
        updatedStudents = updatedStudents.filter((s) => s.id !== oldId);
        return;
      }

      const studentIndex = updatedStudents.findIndex((s) => s.id === oldId);
      if (studentIndex !== -1 && newId.length >= 5) {
        const newGrade = parseInt(newId.substring(0, 1), 10);
        const newClass = parseInt(newId.substring(1, 3), 10);
        const newNum = parseInt(newId.substring(3, 5), 10);

        if (!isNaN(newGrade) && !isNaN(newClass) && !isNaN(newNum)) {
          const studentName = updatedStudents[studentIndex].name;
          const newPhotoUrl = `/photos/${newId}.jpg`;

          updatedStudents[studentIndex] = {
            ...updatedStudents[studentIndex],
            id: newId,
            grade: newGrade,
            classNum: newClass,
            number: newNum,
            photoUrl: newPhotoUrl,
          };
          resultsLog.push({ oldId, newId, name: studentName });
        }
      }
    });

    updatedStudents.sort((a, b) => a.id.localeCompare(b.id));

    try {
      await supabase.from('students').upsert(
        updatedStudents.map((s) => ({
          id: s.id,
          name: s.name,
          grade: s.grade,
          class_num: s.classNum,
          number: s.number,
          photo_url: `/photos/${s.id}.jpg`,
        }))
      );
    } catch (e) {
      console.error(e);
    }

    saveStoredStudents(updatedStudents);
    onStudentsUpdated(updatedStudents);
    setAppliedPromotionResults(resultsLog);
    setIsProcessing(false);
    alert(`🎉 진급 처리가 완료되었습니다! (이동 반영: ${resultsLog.length}명)`);
  };

  const handleDownloadRenameScript = () => {
    if (appliedPromotionResults.length === 0) return;
    let batContent = '@echo off\r\nchcp 65001 > nul\r\n';
    appliedPromotionResults.forEach(({ oldId, newId }) => {
      batContent += `if exist "${oldId}.jpg" ren "${oldId}.jpg" "${newId}.jpg"\r\n`;
    });
    const blob = new Blob([batContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = '사진파일명_새학번_일괄변경.bat';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetAllPenalties = () => {
    if (confirm('🚨 지도 내역을 초기화하시겠습니까?')) {
      onResetPenalties();
    }
  };

  const handleResetAllStudents = async () => {
    if (confirm('🚨 정말로 전체 학생 명단을 DB와 화면에서 완전히 삭제하시겠습니까?\n이 작업은 복구할 수 없습니다.')) {
      try {
        const { error } = await supabase.from('students').delete().gt('id', '');

        if (error) {
          console.error('DB 학생 삭제 중 오류 발생:', error);
          alert('DB 삭제 중 오류가 발생했습니다.');
          return;
        }

        saveStoredStudents([]);
        onStudentsUpdated([]);
        alert('🎉 학생 명단과 Supabase DB 데이터가 성공적으로 초기화되었습니다.');
      } catch (e) {
        console.error(e);
        alert('삭제 처리 중 오류가 발생했습니다.');
      }
    }
  };

  const isTransparent = !logoBgColorInput || logoBgColorInput === 'transparent';
  const isPresetColor = PRESET_COLORS.includes(logoBgColorInput);

  return (
    <div className="w-full max-w-[1550px] mx-auto overflow-hidden">
      {/* ✨ 요청하신 h-[660px] 정확히 고정[cite: 7] */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-stretch h-[660px]">

        {/* 1열: 🏛️ 학교 브랜딩 */}
        <div className="md:col-span-2 bg-white border border-slate-300 rounded-2xl p-3 shadow-sm flex flex-col justify-between h-full min-h-0">
          <div className="space-y-3 overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
              <h2 className="text-[13px] font-bold text-slate-800 flex items-center gap-1">
                <span>🏛️</span> 학교 브랜딩
              </h2>
            </div>

            <div className="space-y-0.5">
              <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100/90 border border-emerald-300 px-1.5 py-0.5 rounded inline-block">
                학교명
              </span>
              <input
                type="text"
                placeholder="예: 한국고등학교"
                value={schoolNameInput}
                onChange={(e) => {
                  const val = e.target.value;
                  setSchoolNameInput(val);
                  updateRealtimeBranding({ schoolName: val });
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-bold text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-0.5">
              <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100/90 border border-emerald-300 px-1.5 py-0.5 rounded inline-block">
                로고
              </span>
              <select
                value={logoTypeInput}
                onChange={(e) => {
                  const newType = e.target.value as 'emoji' | 'image' | 'file';
                  setLogoTypeInput(newType);
                  let newVal = logoValueInput;
                  if (newType === 'emoji' && !logoValueInput) newVal = '⚖️';
                  else if (newType === 'file') newVal = '';
                  setLogoValueInput(newVal);
                  updateRealtimeBranding({ logoType: newType, logoValue: newVal });
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-1.5 py-1 font-bold text-xs text-slate-900 focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="emoji">대표 이모지</option>
                <option value="image">웹 이미지(URL)</option>
                <option value="file">📁 직접 파일 등록</option>
              </select>
            </div>

            <div className="space-y-0.5">
              <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100/90 border border-emerald-300 px-1.5 py-0.5 rounded inline-block">
                {logoTypeInput === 'emoji' ? '이모지' : logoTypeInput === 'image' ? 'URL' : '파일'}
              </span>

              {logoTypeInput === 'file' ? (
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoFileUpload}
                  className="w-full text-[10px] text-slate-500 file:mr-1 file:py-0.5 file:px-1.5 file:rounded file:border-0 file:font-bold file:bg-emerald-600 file:text-white cursor-pointer"
                />
              ) : logoTypeInput === 'emoji' ? (
                <div className="space-y-1">
                  <input
                    type="text"
                    value={logoValueInput}
                    onChange={(e) => {
                      const val = e.target.value;
                      setLogoValueInput(val);
                      updateRealtimeBranding({ logoValue: val });
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg text-center font-bold text-sm text-slate-900 focus:outline-none focus:border-emerald-500 py-0.5"
                  />
                  <div className="flex items-center justify-between bg-slate-50 border border-slate-300 rounded-lg p-0.5">
                    {['⚖️', '🏫', '🛡️', '🎓', '🚩'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => {
                          setLogoValueInput(emoji);
                          updateRealtimeBranding({ logoValue: emoji });
                        }}
                        className={`px-1 py-0.5 rounded text-xs hover:bg-emerald-100 transition-all cursor-pointer ${
                          logoValueInput === emoji ? 'bg-emerald-200 font-bold border border-emerald-400' : ''
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <input
                  type="text"
                  placeholder="https://..."
                  value={logoValueInput}
                  onChange={(e) => {
                    const val = e.target.value;
                    setLogoValueInput(val);
                    updateRealtimeBranding({ logoValue: val });
                  }}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-bold text-xs text-slate-900 focus:outline-none"
                />
              )}
            </div>

            <div className="space-y-0.5">
              <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100/90 border border-emerald-300 px-1.5 py-0.5 rounded inline-block">
                배경색
              </span>

              <div className="flex items-center gap-1 w-full">
                <div
                  className="w-6 h-6 rounded-lg border border-slate-400 flex items-center justify-center text-xs font-bold shrink-0 overflow-hidden"
                  style={{
                    backgroundColor: isTransparent ? '#ffffff' : logoBgColorInput,
                    backgroundImage: isTransparent
                      ? 'repeating-conic-gradient(#cbd5e1 0% 25%, #ffffff 0% 50%)'
                      : 'none',
                    backgroundSize: '8px 8px',
                  }}
                >
                  {logoTypeInput === 'emoji' ? (
                    logoValueInput || '⚖️'
                  ) : logoValueInput ? (
                    <img src={logoValueInput} alt="로고" className="w-full h-full object-contain" />
                  ) : (
                    '⚖️'
                  )}
                </div>

                <select
                  value={isTransparent ? 'transparent' : isPresetColor ? logoBgColorInput : 'custom'}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val !== 'custom') {
                      setLogoBgColorInput(val);
                      updateRealtimeBranding({ logoBgColor: val });
                    }
                  }}
                  className="flex-1 min-w-0 bg-slate-50 border border-slate-300 rounded-lg px-1 py-0.5 font-bold text-[10px] text-slate-900 focus:outline-none cursor-pointer truncate"
                >
                  <option value="transparent">⚪ 투명</option>
                  <option value="#ffffff">⬜ 흰색</option>
                  <option value="#d1fae5">🟢 에메랄드</option>
                  <option value="#dbeafe">🔵 파란색</option>
                  <option value="#fef3c7">🟡 노란색</option>
                  <option value="#fce7f3">🌸 분홍색</option>
                  {!isPresetColor && <option value="custom">🎨 지정</option>}
                </select>

                <button
                  type="button"
                  onClick={openColorPicker}
                  className="hover:bg-slate-200 text-slate-700 font-bold px-1 py-0.5 border border-slate-300 rounded-lg text-xs cursor-pointer shrink-0"
                >
                  🎨
                </button>

                <input
                  ref={colorInputRef}
                  type="color"
                  value={logoBgColorInput.startsWith('#') ? logoBgColorInput : '#ffffff'}
                  onChange={(e) => {
                    const val = e.target.value;
                    setLogoBgColorInput(val);
                    updateRealtimeBranding({ logoBgColor: val });
                  }}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleSaveBranding}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs transition-all shadow-sm cursor-pointer shrink-0 mt-1 flex items-center justify-center gap-1"
          >
            <span>💾</span>
            <span>저장</span>
          </button>
        </div>

        {/* 2열: ⚙️ 시스템 종합 설정 */}
        <div className="md:col-span-4 bg-white border border-slate-300 rounded-2xl p-2 shadow-sm flex flex-col justify-between h-full min-h-0 space-y-0.5">

          {/* 1) 사진 표시 설정 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>🖼️</span> 현장 지도 학생 사진 표시 설정
              </h2>
            </div>
            <div className="grid grid-cols-3 gap-1 pt-0.5">
              <button
                type="button"
                onClick={() => {
                  onPhotoConfigChange('always_on');
                  saveConfigToSupabase('photo_config', 'always_on');
                  alert('🎉 사진 표시가 [켜기]로 설정되었습니다.');
                }}
                className={`py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  photoConfig === 'always_on' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                켜기
              </button>
              <button
                type="button"
                onClick={() => {
                  onPhotoConfigChange('always_off');
                  saveConfigToSupabase('photo_config', 'always_off');
                  alert('🎉 사진 표시가 [끄기]로 설정되었습니다.');
                }}
                className={`py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  photoConfig === 'always_off' ? 'bg-rose-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                끄기
              </button>
              <button
                type="button"
                onClick={() => {
                  onPhotoConfigChange('allow_toggle');
                  saveConfigToSupabase('photo_config', 'allow_toggle');
                  alert('🎉 사진 표시가 [자율]로 설정되었습니다.');
                }}
                className={`py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  photoConfig === 'allow_toggle' ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                자율
              </button>
            </div>
          </div>

          {/* 2) 학년별 총 학급 수 설정 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>🏢</span> 학년별 총 학급 수 설정
              </h2>
            </div>
            <div className="grid grid-cols-3 gap-1 pt-0.5">
              {[1, 2, 3].map((g) => (
                <div key={g} className="bg-white border border-slate-300 rounded-lg px-1 py-0.5 flex items-center justify-center gap-1">
                  <span className="text-[10px] font-bold text-slate-600 shrink-0">{g}학년</span>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={classCounts[g as keyof ClassCounts] ?? 1}
                    onChange={(e) => handleClassCountChangeAndSave(g, Number(e.target.value))}
                    className="w-8 border border-slate-300 rounded text-center font-black text-xs text-emerald-700 bg-white focus:outline-none"
                  />
                  <span className="text-[10px] font-bold text-slate-600 shrink-0">반</span>
                </div>
              ))}
            </div>
          </div>

          {/* 3) 단계별 기준 횟수 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5 flex justify-between items-center">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>🎯</span> 학생 생활 지도 단계별 기준 횟수
              </h2>
              <button 
                onClick={handleSaveThresholds} 
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-2.5 py-0.5 rounded-md text-[10px] cursor-pointer transition-all shadow-sm"
              >
                저장
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1 pt-0.5">
              <div className="bg-amber-50/80 border border-amber-300 rounded-lg px-1 py-0.5 flex items-center justify-center gap-1">
                <span className="text-[10px] font-bold text-amber-900 shrink-0">1단계(경고)</span>
                <input
                  type="number"
                  value={warningInput}
                  onChange={(e) => setWarningInput(Number(e.target.value))}
                  className="w-10 border border-amber-300 rounded text-center font-black text-xs bg-white focus:outline-none"
                />
              </div>

              <div className="bg-rose-50/80 border border-rose-300 rounded-lg px-1 py-0.5 flex items-center justify-center gap-1">
                <span className="text-[10px] font-bold text-rose-900 shrink-0">2단계(집중)</span>
                <input
                  type="number"
                  value={focusInput}
                  onChange={(e) => setFocusInput(Number(e.target.value))}
                  className="w-10 border border-rose-300 rounded text-center font-black text-xs bg-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* 4) PDF 등록 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5 flex justify-between items-center">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>📜</span> 학생 생활 지도 규정 등록 (PDF)
              </h2>
              {rulesPdfUrl ? (
                <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-1 py-0.5 rounded">
                  ✓ 등록됨
                </span>
              ) : (
                <span className="text-[9px] font-bold text-slate-400 bg-slate-100 px-1 py-0.5 rounded">
                  미등록
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 pt-0.5">
              <label className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-1.5 rounded-lg text-xs transition-all shadow-sm cursor-pointer text-center">
                📁 파일 선택
                <input
                  type="file"
                  accept="application/pdf"
                  onChange={handlePdfFileUpload}
                  className="hidden"
                />
              </label>
              {rulesPdfUrl && (
                <button
                  type="button"
                  onClick={handleDeletePdf}
                  className="bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 font-bold px-2 py-1.5 rounded-lg text-xs shrink-0 cursor-pointer transition-all"
                >
                  삭제
                </button>
              )}
            </div>
          </div>

          {/* 5) 시연용 초기 데이터 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>🎁</span> 시연용 초기 데이터 세팅
              </h2>
            </div>
            <button
              onClick={handleGenerateInitialData}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 rounded-lg text-xs transition-all shadow-sm cursor-pointer mt-0.5 flex items-center justify-center gap-1"
            >
              <span>⚡</span>
              <span>초기 샘플 데이터 즉시 생성하기</span>
            </button>
          </div>

          {/* 6) 외부 접속 구동 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1 truncate">
                <span>🌐</span> 스마트폰 외부 접속(LTE/집) 구동 설정
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-1 pt-0.5">
              <button
                type="button"
                onClick={() => handleTunnelModeChange('hybrid')}
                className={`py-1.5 rounded-lg border text-center transition-all cursor-pointer flex items-center justify-center gap-0.5 text-xs font-bold ${
                  tunnelMode === 'hybrid' ? 'bg-blue-50 border-blue-500 text-blue-900 font-black' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>⚡ 하이브리드</span>
                {tunnelMode === 'hybrid' && <span className="text-blue-600 text-[9px]">✓</span>}
              </button>

              <button
                type="button"
                onClick={() => handleTunnelModeChange('auto')}
                className={`py-1.5 rounded-lg border text-center transition-all cursor-pointer flex items-center justify-center gap-0.5 text-xs font-bold ${
                  tunnelMode === 'auto' ? 'bg-emerald-50 border-emerald-500 text-emerald-900 font-black' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>🚀 자동</span>
                {tunnelMode === 'auto' && <span className="text-emerald-600 text-[9px]">✓</span>}
              </button>

              <button
                type="button"
                onClick={() => handleTunnelModeChange('manual')}
                className={`py-1.5 rounded-lg border text-center transition-all cursor-pointer flex items-center justify-center gap-0.5 text-xs font-bold ${
                  tunnelMode === 'manual' ? 'bg-purple-50 border-purple-500 text-purple-900 font-black' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>🔒 수동</span>
                {tunnelMode === 'manual' && <span className="text-purple-600 text-[9px]">✓</span>}
              </button>
            </div>
          </div>

          {/* 7) DB 연동 변경 */}
          <div className="bg-blue-50/50 border border-blue-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-blue-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-blue-900 flex items-center gap-1">
                <span>🔑</span> 학교 DB 연동 설정 변경
              </h2>
            </div>
            <button
              onClick={handleResetDbConfig}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-1.5 rounded-lg text-xs transition-all shadow-sm cursor-pointer mt-0.5 flex items-center justify-center gap-1"
            >
              <span>⚡</span>
              <span>DB Key 연동 해제 및 재설정하기</span>
            </button>
          </div>

          {/* 8) 데이터 운영 초기화 */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-1 flex flex-col justify-center">
            <div className="border-b border-slate-200/60 pb-0.5">
              <h2 className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                <span>⚙️</span> 데이터 운영 초기화
              </h2>
            </div>
            <div className="flex gap-1 items-center justify-between pt-0.5">
              <button onClick={handleResetAllPenalties} className="flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-1.5 rounded-lg text-xs transition-all cursor-pointer shadow-sm">
                🚨 지도 내역 초기화
              </button>
              <button onClick={handleResetAllStudents} className="flex-1 bg-rose-600 hover:bg-rose-700 text-white font-bold py-1.5 rounded-lg text-xs transition-all cursor-pointer shadow-sm">
                🎓 학생 명단 초기화
              </button>
            </div>
          </div>

        </div>

        {/* 3열: 🔀 새 학기 진급 학번 입력 */}
        <div className="md:col-span-3 bg-white border border-slate-200 rounded-2xl p-3 shadow-sm flex flex-col justify-between h-full min-h-0">
          <div className="space-y-1.5 flex-1 flex flex-col min-h-0">
            <div className="border-b border-slate-100 pb-1 shrink-0">
              <h2 className="text-[13px] font-bold text-slate-800 flex items-center gap-1">
                <span>🔀</span> 새 학기 진급 학번 입력
              </h2>
              <p className="text-[10px] text-slate-400">
                엑셀 2개 열 또는 3개 열 복사 지원 (졸업생 처리 자동)
              </p>
            </div>
            <textarea
              placeholder={`[엑셀 복사/붙여넣기 예시]\n10101   20101\n10102   홍길동   20102\n30101   졸업`}
              value={promotionText}
              onChange={(e) => setPromotionText(e.target.value)}
              className="w-full flex-1 bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-mono resize-none focus:outline-none"
            />
          </div>
          <button onClick={handleApplyPromotion} disabled={isProcessing} className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl text-xs mt-1.5 cursor-pointer shrink-0 shadow-md">
            {isProcessing ? '⏳ 처리 중...' : `1️⃣ 진급 학번 매칭 반영하기 (${previewData.length}명)`}
          </button>
        </div>

        {/* 4열: 👁️ 실시간 진급 매칭 미리보기 */}
        <div className="md:col-span-3 bg-white border border-slate-200 rounded-2xl p-3 shadow-sm flex flex-col justify-between h-full min-h-0">
          <div className="space-y-1.5 flex-1 flex flex-col min-h-0">
            <div className="border-b border-slate-100 pb-1 shrink-0">
              <h2 className="text-[13px] font-bold text-slate-800 flex items-center gap-1 truncate">
                <span>👁️</span> 실시간 진급 매칭 미리보기
              </h2>
            </div>

            <div className="flex-1 overflow-y-auto border border-slate-200 rounded-xl bg-slate-50 mt-0.5 min-h-0">
              {previewData.length === 0 ? (
                <div className="text-center text-slate-400 h-full flex items-center justify-center text-xs p-4">
                  진급 명단을 붙여넣어 주세요.
                </div>
              ) : (
                <div className="divide-y divide-slate-200">
                  {previewData.map((item, idx) => (
                    <div key={idx} className="p-2 flex justify-between text-xs items-center">
                      <span className="w-1/3 font-mono font-bold text-slate-500">{item.oldId}</span>
                      <span className="w-1/3 text-center font-bold text-slate-900 truncate">{item.name}</span>
                      <span className={`w-1/3 text-right font-mono font-bold ${item.newId.includes('졸업') ? 'text-rose-500' : 'text-emerald-600'}`}>
                        ➔ {item.newId}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="mt-1.5 shrink-0">
            {appliedPromotionResults.length > 0 ? (
              <button
                onClick={handleDownloadRenameScript}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-xl text-xs transition-all shadow-sm cursor-pointer flex items-center justify-center gap-1 truncate"
              >
                <span>📂</span> 2️⃣ 사진명 변경파일(.bat) 받기
              </button>
            ) : (
              <button
                disabled
                className="w-full bg-slate-100 text-slate-400 font-bold py-2.5 rounded-xl text-xs border border-slate-200 cursor-not-allowed text-center truncate"
              >
                📂 2️⃣ 사진명 변경파일(.bat) 받기
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default SystemConfigTab;