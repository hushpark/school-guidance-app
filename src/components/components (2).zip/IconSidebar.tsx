import React, { useState } from 'react';
import type { MainTab, SchoolBranding } from '../types';

export type UserRole = 'admin' | 'manager' | 'teacher';

interface IconSidebarProps {
  role: UserRole;
  activeTab: MainTab;
  setActiveTab: (tab: MainTab) => void;
  schoolBranding?: SchoolBranding;
  isExternalAccess?: boolean;
}

export const IconSidebar: React.FC<IconSidebarProps> = ({
  role,
  activeTab,
  setActiveTab,
  schoolBranding,
  isExternalAccess = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const mainNavItems = [
    { 
      id: 'realtime', 
      label: '실시간 생활지도', 
      icon: '⚡', 
      show: role !== 'teacher' 
    },
    { 
      id: 'photoSearch', 
      label: '학생 사진/정보 조회', 
      icon: '🔍', 
      show: !isExternalAccess 
    },
    { 
      id: 'classGrid', 
      label: '반별 / 기준별 누적 명단', 
      icon: '📊', 
      show: !isExternalAccess 
    },
    { 
      id: 'studentManage', 
      label: '학생 명단 관리', 
      icon: '✍️', 
      show: role === 'admin' && !isExternalAccess 
    },
    { 
      id: 'teacherManage', 
      label: '교사 계정 관리', 
      icon: '🔑', 
      show: role === 'admin' 
    },
    { 
      id: 'systemConfig', 
      label: '시스템 & 진급 설정', 
      icon: '⚙️', 
      show: role === 'admin' && !isExternalAccess 
    },
  ];

  const helpItem = { 
    id: 'helpGuide', 
    label: '사용 가이드', 
    icon: '❓',
    show: !isExternalAccess 
  };

  const isTransparent = !schoolBranding?.logoBgColor || schoolBranding.logoBgColor === 'transparent';

  const handleTabClick = (id: MainTab) => {
    setActiveTab(id);
    setIsOpen(false);
  };

  return (
    <>
      {/* 📱 모바일 햄버거 토글 버튼 */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-2.5 left-2.5 z-[99] bg-[#0f172a] text-white w-9 h-9 rounded-xl shadow-lg border border-slate-700 active:scale-95 transition-all cursor-pointer flex items-center justify-center font-bold"
        aria-label="메뉴 열기/닫기"
      >
        <span className="text-base">{isOpen ? '✕' : '☰'}</span>
      </button>

      {/* 📱 모바일 어두운 배경 오버레이 */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="md:hidden fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[80] transition-opacity"
        />
      )}

      {/* 🏛️ 사이드바 바디 (모바일 메뉴 열림 시 상단 패딩 pt-14 부여로 X버튼과 로고 안겹치게 수정) */}
      <div
        className={`fixed md:static top-0 left-0 h-screen w-16 bg-[#0f172a] flex flex-col items-center pt-14 md:pt-5 pb-5 border-r border-slate-800 shrink-0 z-[90] justify-between transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* 🔝 상단 로고 */}
        <div className="w-full flex flex-col items-center">
          <div className="mb-6">
            <div
              className={`w-11 h-11 flex items-center justify-center text-xl ${
                isTransparent
                  ? 'bg-transparent border-none shadow-none p-0'
                  : 'rounded-2xl border border-slate-700/50 shadow-sm p-0.5'
              }`}
              style={{
                backgroundColor: isTransparent ? 'transparent' : schoolBranding?.logoBgColor,
              }}
            >
              {schoolBranding?.logoType === 'emoji' ? (
                <span>{schoolBranding?.logoValue || '🛡️'}</span>
              ) : schoolBranding?.logoValue ? (
                <img
                  src={schoolBranding.logoValue}
                  alt="학교 로고"
                  className="w-full h-full object-contain rounded-lg"
                />
              ) : (
                <span>🛡️</span>
              )}
            </div>
          </div>

          {/* 메인 메뉴 버튼들 */}
          <div className="space-y-3.5 w-full px-2 flex flex-col items-center">
            {mainNavItems
              .filter((item) => item.show)
              .map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabClick(item.id as MainTab)}
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl cursor-pointer transition-colors ${
                      isActive
                        ? 'bg-slate-800 text-emerald-400 font-bold border border-slate-700 shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                    }`}
                    title={item.label}
                  >
                    <span>{item.icon}</span>
                  </button>
                );
              })}
          </div>
        </div>

        {/* ⬇️ 하단 사용 가이드 */}
        {helpItem.show && (
          <div className="w-full px-2 flex justify-center">
            <button
              onClick={() => handleTabClick(helpItem.id as MainTab)}
              className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl cursor-pointer transition-colors ${
                activeTab === helpItem.id
                  ? 'bg-slate-800 text-rose-400 font-bold border border-slate-700 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
              title={helpItem.label}
            >
              <span>{helpItem.icon}</span>
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default IconSidebar;